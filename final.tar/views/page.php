<?php

echo 'Welcome '.$name.'!';