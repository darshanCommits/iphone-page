<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <!-- ZKIN UI KIT CSS -->
    <link rel="stylesheet" href="assets/css/zkin-ui-kit.min.css">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;subset=latin-ext" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700,700i,900,900i&amp;subset=latin-ext" rel="stylesheet">

    <!-- fontawesome -->
    <script src="https://kit.fontawesome.com/c676ee18e9.js" crossorigin="anonymous"></script>
    <!-- hero -->
    <link rel="stylesheet" href="./assets/css/hero.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
    <script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js">
        swiper.init()
    </script>
    <script src="./assets/js/util.js" defer></script>
    <script src="./assets/js/app.js" defer></script>
    <style>
        .card:hover {
            box-shadow: 0 0 10px rgba(0, 0, 255, 0.5);

            transition: box-shadow 0.3s ease-in-out;
        }

        .border {
            border-radius: 10px;
        }

        .card:hover .border {
            background-color: #26bdeb;
            transition: background-color 0.3s ease-in-out;
        }

        .card-img {
            max-width: 60%;
            height: auto;
            margin-bottom: 20px;
        }

        .card:hover .border h5 {
            color: white;
        }

    </style>

    <title>SOS Master</title>
</head>

<body>
    <?php include('navbar.php'); ?>

    <!-- start of hero section -->
    <div id="phoneDes">
      <div id="info">
        <div id="infoText"></div>
        <div id="buttons">
          <button id="black" data-device="iPhone" data-slide="0">iPhone</button>
          <button id="red" data-device="iPad" data-slide="1">iPad</button>
          <button id="cyan" data-device="MacBook" data-slide="2">MacBook</button>
          <button id="green" data-device="iMac" data-slide="3">iMac</button>
          <button id="purple" data-device="Computer" data-slide="4">Computer</button>
          <button id="blue" data-device="Data Recovery" data-slide="5">Data Recovery</button>
        </div>
          <button id="calculator"><a href="#">Calculator</a></button>
       </div>
      <div class="products-container">
        <div id="image" class="swiper-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <img src="./assets/img/hero-iphone.webp" alt="iphone" />
            </div>

            <div class="swiper-slide">
              <img src="./assets/img/hero-ipad.webp" alt="ipad" />
            </div>

            <div class="swiper-slide">
              <img src="./assets/img/hero-macbook.webp" alt="macbook" />
            </div>

            <div class="swiper-slide">
              <img src="./assets/img/hero-imac.webp" alt="imac" />
            </div>

            <div class="swiper-slide">
              <img src="./assets/img/hero-computer.webp" alt="computer" />
            </div>

            <div class="swiper-slide">
              <img src="./assets/img/hero-storage.webp" alt="storage" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- End of hero section -->

    <!-- start of calculator section -->
    <div class="py-3"></div>
    <h1 class="section-title-2 text-center font-weight-800 text-uppercase mb-4">Choose Your Device</h1>
    <div class="text-center mt-2">
        <p><strong>Choose the device you want to repair. Our calculator will help you to give you estimated repair cost.</strong></p>
    </div>
    <div class="py-3"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-3">
                <a href="repair-apple" class="card border-0">
                    <div class="card-body text-center shadow">
                        <img src="assets/img/company/apple.png" alt="Apple" class="card-img">
                        <div class="border p-3 mt-3 d-flex justify-content-center align-items-center">
                            <h5 class="card-title my-auto">Apple</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 col-lg-3">
                <a href="#" class="card border-0">
                    <div class="card-body text-center shadow">
                        <img src="assets/img/company/computer.png" alt="computer repair icon" class="card-img">
                        <div class="border p-3 mt-3 d-flex justify-content-center align-items-center">
                            <h5 class="card-title my-auto">Computer</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 col-lg-3">
                <a href="#" class="card border-0">
                    <div class="card-body text-center shadow">
                        <img src="assets/img/company/ps4.png" alt="ps 5 repair icon" class="card-img">
                        <div class="border p-3 mt-3 d-flex justify-content-center align-items-center">
                            <h5 class="card-title my-auto">PS 5</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 col-lg-3">
                <a href="#" class="card border-0">
                    <div class="card-body text-center shadow">
                        <img src="assets/img/company/hard-disk.png" alt="hard disk repair icon" class="card-img">
                        <div class="border p-3 mt-3 d-flex justify-content-center align-items-center">
                            <h5 class="card-title my-auto">Data Recovery</h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
    <!-- end of calculator -->
    <div class="py-3"></div>
    <!-- start of features section -->
    <div class="section py-4">
        <div class="row pt-3">
            <div class="col-lg-8 offset-lg-2">
                <blockquote class="blockquote text-center">
                    <p class="mb-0">18 years of trusted expertise in mobile and PC repair, delivering exceptional solutions for all your device needs.</p>
                </blockquote>
                <div class="text-center mb-5">
                    <i class="fas fa-ellipsis-h fa-lg"></i>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body text-center">
                            <img class="mb-3" src="https://media-public.canva.com/0lPD8/MAFP7x0lPD8/1/tl.png" alt="features" width="80" height="80">
                            <h5 class="card-title">18 Years Of Experience</h5>
                            <p class="card-text">Our company stands as a true testament to our commitment, knowledge, and ability to adapt to the ever-evolving technological landscape.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body text-center">
                            <img class="mb-3" src="https://media-public.canva.com/QY8BA/MAFhskQY8BA/1/tl.png" alt="features" width="80" height="80">
                            <h5 class="card-title">Skilled and Certified Technicians</h5>
                            <p class="card-text">Our team consists of highly skilled and certified technicians who are experts in diagnosing and fixing problems with mobile devices and PCs.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body text-center">
                            <img class="mb-3" src="https://media-public.canva.com/JTFGw/MAFeyDJTFGw/1/tl.png" alt="features" width="80" height="80">
                            <h5 class="card-title">Quality Parts and Warranty</h5>
                            <p class="card-text">We believe in using only the highest quality replacement parts for repairs. Whether it's for mobile devices or PCs, we source genuine or OEM parts to ensure optimal performance and longevity.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3">
                    <div class="card border-0 shadow">
                        <div class="card-body text-center">
                            <img class="mb-3" src="https://media-public.canva.com/MLYp4/MAEZj3MLYp4/1/tl.png" alt="features" width="80" height="80">
                            <h5 class="card-title">Cutting-Edge Technology</h5>
                            <p class="card-text">We stay up-to-date with the latest advancements in technology to ensure we can handle repairs for the newest devices and stay ahead of emerging trends. We use state-of-the-art tools and techniques to deliver top-notch repair services.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <h1 class="section-title-2 text-center font-weight-800 text-uppercase mb-4">Frequently Asked Questions!</h1>
    <div class="text-center mt-2">
        <p><strong>We are here to promptly address all your questions and concerns, ensuring a quick resolution and clearing any doubts you may have about our services.</strong></p>
    </div>



    <div class="container">
        <div class="accordion" id="accordionExample">
            <div class="card">
                <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                        <a href="#collapseOne" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseOne">
                            <span class="mr-2">1.</span> Do I need to download any software to use your tools? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
                    <div class="card-body">
                        No, our tools are completely web-based and require no additional downloads or installations. Simply visit our website and start using the tools right away!
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingTwo">
                    <h5 class="mb-0">
                        <a href="#collapseTwo" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseTwo">
                            <span class="mr-2">2.</span> Can I use your tools for free? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample" style="">
                    <div class="card-body">
                        Yes, all of our tools are completely free to use. There are no hidden fees or charges.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingThree">
                    <h5 class="mb-0">
                        <a href="#collapseThree" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseThree">
                            <span class="mr-2">3.</span> Are there any limitations on how many times I can use your tools? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample" style="">
                    <div class="card-body">
                        No, there are no limitations on how many times you can use our tools. You can utilize them as often as you need, without any restrictions.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingFour">
                    <h5 class="mb-0">
                        <a href="#collapseFour" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseFour">
                            <span class="mr-2">4.</span> Is it safe to use your tools? Will my personal information be protected? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                    <div class="card-body">
                        Yes, we take the security of our users very seriously. Our website uses encryption technology to protect your information, and we do not store any personal data.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingFive">
                    <h5 class="mb-0">
                        <a href="#collapseFive" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseFive">
                            <span class="mr-2">5.</span> What types of content can I download using your tools? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                    <div class="card-body">
                        Our tools support a wide range of content, including videos, images, and audio files. We also support downloads from popular platforms like YouTube, Instagram, and more.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingSix">
                    <h5 class="mb-0">
                        <a href="#collapseSix" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseSix">
                            <span class="mr-2">6.</span> How long does it take to process a download? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                    <div class="card-body">
                        The processing time can vary depending on the size and type of content you're downloading, but we've optimized our tools to ensure fast processing speeds.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingSeven">
                    <h5 class="mb-0">
                        <a href="#collapseSeven" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseSeven">
                            <span class="mr-2">7.</span> Do I need to create an account to use your tools? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                    <div class="card-body">
                        No, you do not need to create an account to use our tools. Simply visit our website and start using the tools right away.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingEight">
                    <h5 class="mb-0">
                        <a href="#collapseEight" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseEight">
                            <span class="mr-2">8.</span> Is there a limit on the file size I can download? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
                    <div class="card-body">
                        No, there are no limitations on the file size you can download. Our tools support downloads of all sizes.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingNine">
                    <h5 class="mb-0">
                        <a href="#collapseNine" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseNine">
                            <span class="mr-2">9.</span> Are your tools compatible with all devices and operating systems? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
                    <div class="card-body">
                        Yes, our tools are designed to be compatible with all devices and operating systems. Whether you're using a PC, Mac, or mobile device, you can use our tools with ease.
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header" id="headingTen">
                    <h5 class="mb-0">
                        <a href="#collapseTen" class="btn btn-link collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="collapseTen">
                            <span class="mr-2">10.</span> Can I suggest new tools or features to add to your website? &nbsp;<i class="fas fa-chevron-down float-right" aria-hidden="true"></i>
                        </a>
                    </h5>
                </div>

                <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">
                    <div class="card-body">
                        Yes, we welcome feedback and suggestions from our users. If there's a tool or feature you'd like to see added to our website, please let us know using our contact form.
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="section bg-viridian-500 text-white-50">
        <div class="pt-5 pb-4">
            <div class="container">
                <div class="row pt-5 pb-3">

                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="mb-5">
                            <img class="mb-4" src="assets/images/logo-footer-02-light.png" alt="ZKIN">
                            <p class="mb-0">Fusce adipiscing neque nec arcu rutrum pretium phasellus viverra arcu duis ullamcorper leo nci nunc condimentum consequat enim dictum ullamcorper.</p>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="mb-5">
                            <h6 class="text-white text-uppercase mb-4">Contact</h6>
                            <ul class="fa-ul ml-4 pt-1">
                                <li class="mb-2"><span class="fa-li text-primary"><i class="fas fa-map-marker-alt"></i></span>827 Maxwell Street Hartford CT Connecticut 06103</li>
                                <li class="mb-2"><span class="fa-li text-primary"><i class="fas fa-envelope"></i></span>contact@domainname.com</li>
                                <li><span class="fa-li text-primary"><i class="fas fa-phone"></i></span>+1-123-456-7890</li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="mb-5">
                            <h6 class="text-white text-uppercase mb-4">Latest news</h6>
                            <ul class="list-unstyled pt-1">
                                <li class="mb-4">
                                    <div class="media">
                                        <div class="mr-3">
                                            <a href="#"><img src="assets/images/footer-latest-news-01.jpg" class="rounded-circle shadow" alt="News"></a>
                                        </div>
                                        <div class="media-body">
                                            <strong class="d-block mb-1 text-primary font-italic">News heading</strong>
                                            Nulla metus scelerisue ante sollicitudin
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="media">
                                        <div class="mr-3">
                                            <a href="#"><img src="assets/images/footer-latest-news-02.jpg" class="rounded-circle shadow" alt="News"></a>
                                        </div>
                                        <div class="media-body">
                                            <strong class="d-block mb-1 text-primary font-italic">News heading</strong>
                                            Nulla metus scelerisue ante sollicitudin
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-4 col-xl-3">
                        <div class="mb-5">
                            <h6 class="text-white text-uppercase mb-4">Subscribe</h6>
                            <div class="pb-3">
                                <p>Stay up to date with all events coming straight in your mailbox.</p>
                            </div>
                            <form class="form-light-1 mb-2">
                                <div class="input-group input-group-round">
                                    <div class="input-group-inner">
                                        <input type="email" class="form-control" placeholder="Your email" aria-label="Your email" aria-describedby="button-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-round btn-primary shadow-none mb-0" type="button" id="button-addon2">Submit</button>
                                        </div>
                                        <div class="input-focus-bg"></div>
                                    </div>
                                </div>
                            </form>
                            <p class="mb-0"><small>* Personal data will be encrypted</small></p>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="py-4 border-top border-dark">
            <div class="container">
                <div class="row text-center">
                    <div class="col">
                        <p class="mb-0"><small>Copyright @ <a href="#">pophonic.com</a> 2020. All Rights Reserved.</small></p>
                    </div>
                </div>
            </div>
        </div>
    </div>




    <script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
    <!-- ZKIN UI KIT js -->
    <script src="assets/js/zkin-ui-kit.js"></script>

    <!-- Bootstrap js -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>


</html>